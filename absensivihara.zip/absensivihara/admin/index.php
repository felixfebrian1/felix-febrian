<?php
	session_start();
	
	header("location:pages/dashboard.php?page=home");
?>