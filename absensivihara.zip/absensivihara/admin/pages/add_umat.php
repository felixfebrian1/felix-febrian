<?php
	//jika session user_login telah dimasukan
	if(!isset($_SESSION['adminlogin'])){
		//dialihkan ke home bila sudah ada session user_login
		header("location:login.php");
	}
?>
<div class="box">
	<div class="box-header">
		<h3 class="box-title"></h3>
	</div>
	<div class="box-body">
		<div class="row">
			<div class="panel panel-default">
				<div class="panel-heading">
					<?php
						$message = $_GET['message'];
						echo "<span style='color:red;'>".$message."</span>";
					?>
					<h3 class="panel-title">Add umat</h3>
				</div>
				<div class="panel-body">
						<form action="dashboard.php?page=add_umat_query" method="post" name="register-form required">
							<input type="text" name="nama" id="nama" class="form-control" placeholder="Nama" required><br/>
							<input type="text" name="notelp" id="notelp" class="form-control" placeholder="No Telp" required><br/>
							<input type="text" name="tempat" id="tempat" class="form-control" placeholder="Tempat" required><br/>
							<input type="date" name="tanggallahir" id="tanggallahir" class="form-control" placeholder="Tanggal Lahir" required><br/>
							<input type="text" name="alamat" id="alamat" class="form-control" placeholder="Alamat" required><br/>
							<select name="role" class="form-control" required>
								<option value="petugas">Petugas</option>
								<option value="umat" selected>Umat</option>
							</select><br/>
							<input type="text" name="usercode" id="alamat" class="form-control" placeholder="Usercode" required><br/>
							<select name="status" class="form-control" required>
								<option value="active" <?php echo $status == 'active' ? 'selected' : '' ?>>Active</option>
								<option value="Pending" <?php echo $status == 'pending' ? 'selected' : '' ?>>pending</option>
							</select><br/>
							<input type="submit" name="register" value="Register" class="btn btn-default">
							<a href="dashboard.php?page=umat" class="btn btn-default">Back</a>
						</form>
				</div>
			</div>
		</div>
	</div>
</div>