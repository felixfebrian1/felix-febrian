<?php
	//jika session user_login telah dimasukan
	if(!isset($_SESSION['adminlogin'])){
		//dialihkan ke home bila sudah ada session user_login
		header("location:login.php");
	}
?>
<?php
	if($_POST['role'] == "petugas"){
		if(isset($_POST['register'])){
				// umat
				$nama = $_POST['nama'];
				$notelp = $_POST['notelp'];
				$tempat = $_POST['tempat'];
				$tanggallahir = $_POST['tanggallahir'];
				$alamat = $_POST['alamat'];
				$role = $_POST['role'];
				$usercode = $_POST['usercode'];
				$status = $_POST['status'];
				$photo = "-";
				// admin
				$username = '-';
				$password = '-';
				$divisi = '-';
					
				$sql="select * from user where usercode = '$usercode'";
				$query = mysqli_query($connection,$sql)or die($connection);
				
				if(mysqli_num_rows($query)=="0")
				{
					mysqli_query($connection,"INSERT INTO admin (nama, notelp, username, password, divisi) VALUES ('$nama','$notelp','$username','$password','$divisi')");

					mysqli_query($connection,"INSERT INTO user (nama, notelp, tempat, tanggallahir, alamat, role, usercode, photo, active) VALUES ('$nama','$notelp','$tempat','$tanggallahir','$alamat','$role','$usercode','$photo', '$status')");

					echo '<div class="alert alert-success" role="alert"><strong>Success!</strong> '.$nama.' is successful uploaded</div>';
					echo '<a href="dashboard.php?page=add_umat" class="btn btn-default">Add umat</a> <a href="dashboard.php?page=umat" class="btn btn-default">View umat</a>';
				}
				else
				{
					while ($row=mysqli_fetch_array($query))
					{
						if($usercode=="$row[usercode]");
						echo '<div class="alert alert-danger" role="alert"><strong>Failed!</strong> Usercode : '.$usercode.' is already used</div>';
						echo '<a href="dashboard.php?page=add_umat" class="btn btn-default">Add umat</a> <a href="dashboard.php?page=umat" class="btn btn-default">View umat</a>';
					}
				}
		}
	}
	else{
		if(isset($_POST['register'])){
				$nama = $_POST['nama'];
				$notelp = $_POST['notelp'];
				$tempat = $_POST['tempat'];
				$tanggallahir = $_POST['tanggallahir'];
				$alamat = $_POST['alamat'];
				$role = $_POST['role'];
				$usercode = $_POST['usercode'];
				$status = $_POST['status'];
				$photo = "-";
					
				$sql="select * from user where usercode = '$usercode'";
				$query = mysqli_query($connection,$sql)or die($connection);
				
				if(mysqli_num_rows($query)=="0")
				{
					mysqli_query($connection,"INSERT INTO user (nama, notelp, tempat, tanggallahir, alamat, role, usercode, photo, active) VALUES ('$nama','$notelp','$tempat','$tanggallahir','$alamat','$role','$usercode','$photo', '$status')");

					echo '<div class="alert alert-success" role="alert"><strong>Success!</strong> '.$nama.' is successful uploaded</div>';
					echo '<a href="dashboard.php?page=add_umat" class="btn btn-default">Add umat</a> <a href="dashboard.php?page=umat" class="btn btn-default">View umat</a>';
				}
				else
				{
					while ($row=mysqli_fetch_array($query))
					{
						if($usercode=="$row[usercode]");
						echo '<div class="alert alert-danger" role="alert"><strong>Failed!</strong> Usercode : '.$usercode.' is already used</div>';
						echo '<a href="dashboard.php?page=add_umat" class="btn btn-default">Add umat</a> <a href="dashboard.php?page=umat" class="btn btn-default">View umat</a>';
					}
				}
		}
	}
?>