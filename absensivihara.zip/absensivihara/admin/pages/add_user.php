<?php
	//jika session user_login telah dimasukan
	if(!isset($_SESSION['adminlogin'])){
		//dialihkan ke home bila sudah ada session user_login
		header("location:login.php");
	}
?>
<div class="box">
	<div class="box-header">
		<h3 class="box-title"></h3>
	</div>
	<div class="box-body">
		<div class="row">
			<div class="panel panel-default">
				<div class="panel-heading">
					<?php
						$message = $_GET['message'];
						echo "<span style='color:red;'>".$message."</span>";
					?>
					<h3 class="panel-title">Add user</h3>
				</div>
				<div class="panel-body">
						<form action="dashboard.php?page=add_user_query" method="post" name="register-form required">
							<input type="text" name="firstname" id="firstname" class="form-control" placeholder="First name" required><br/>
							<input type="text" name="lastname" id="lastname" class="form-control" placeholder="Last name" required><br/>
							<input type="email" name="email" id="email" class="form-control" placeholder="example@example.com" required><br/>
							<input type="text" name="username" id="username" class="form-control" placeholder="username" required><br/>
							<input type="password" name="password" id="password" class="form-control" placeholder="password" required><br/>
							<select name="rule" class="form-control" required>
								<option value="admin">Admin</option>
								<option value="user" selected>User</option>
							</select><br/>
							<select name="status" class="form-control" required>
								<option value="active" <?php echo $status == 'active' ? 'selected' : '' ?>>Active</option>
								<option value="Pending" <?php echo $status == 'pending' ? 'selected' : '' ?>>pending</option>
							</select><br/>
							<input type="submit" name="register" value="Register" class="btn btn-default">
							<a href="dashboard.php?page=users" class="btn btn-default">Back</a>
						</form>
				</div>
			</div>
		</div>
	</div>
</div>