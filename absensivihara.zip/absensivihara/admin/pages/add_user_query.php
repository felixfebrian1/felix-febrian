<?php
	//jika session user_login telah dimasukan
	if(!isset($_SESSION['adminlogin'])){
		//dialihkan ke home bila sudah ada session user_login
		header("location:login.php");
	}
?>
<?php
	if(isset($_POST['register'])){
			$firstname = $_POST['firstname'];
			$lastname = $_POST['lastname'];
			$email = $_POST['email'];
			$username = $_POST['username'];
			$status = $_POST['status'];
			$rule = $_POST['rule'];
			$password = md5($_POST['password']);
			$date = date('Y-m-d H:i:s');
				
			$sql="select * from users where username = '$username'";
			$query = mysqli_query($connection,$sql)or die($connection);
			
			if(mysqli_num_rows($query)=="0")
			{
				mysqli_query($connection,"INSERT INTO users (firstname, lastname, email, username, password, date_register, status, rule) VALUES ('$firstname','$lastname','$email','$username','$password','$date','$status','$rule')");
				/*
				echo "$firstname";
				echo "$lastname";
				echo "$email";
				echo "$username";
				echo "$password";
				echo "$status";
				echo "$rule";
				*/
				echo '<div class="alert alert-success" role="alert"><strong>Success!</strong> '.$username.' is successful uploaded</div>';
				echo '<a href="dashboard.php?page=add_user" class="btn btn-default">Add user</a> <a href="dashboard.php?page=users" class="btn btn-default">View users</a>';
			}
			else
			{
				while ($row=mysqli_fetch_array($query))
				{
					if($username=="$row[username]");
					echo '<div class="alert alert-danger" role="alert"><strong>Failed!</strong> username : '.$username.' is already used</div>';
					echo '<a href="dashboard.php?page=add_user" class="btn btn-default">Add user</a> <a href="dashboard.php?page=users" class="btn btn-default">View users</a>';
				}
			}
	}
?>