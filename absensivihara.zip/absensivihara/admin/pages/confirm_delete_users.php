<?php
	//jika session user_login telah dimasukan
	if(!isset($_SESSION['adminlogin'])){
		//dialihkan ke home bila sudah ada session user_login
		header("location:login.php");
	}
?>
<?php
	$select = "SELECT * FROM users WHERE username='".$_GET['username']."'";
	$query = mysqli_query($connection,$select);
	if(mysqli_num_rows($query) > 0){
		$data=mysqli_fetch_object($query);
		$id = $data->id;
		$username = $data->username;
	
	echo '<div class="alert alert-warning" role="alert"><strong>Delete!</strong> <p>Username : '.$username.'</p><br> Are you sure ?
			</div>';
	echo '<a href="dashboard.php?page=delete_users_query&username='.$username.'" class="btn btn-danger">Delete</a> <a href="dashboard.php?page=users" class="btn btn-default">Back</a>';
}
?>
