<?php

	//metode mysqli

	$connection=mysqli_connect('localhost','root','','absensivihara')or die('Error connection to database');

	date_default_timezone_set('Asia/Jakarta');

?>