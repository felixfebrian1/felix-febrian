    <?php
    session_start();
    include_once "connection.php";
    	//jika session user_login telah dimasukan
    	if(!isset($_SESSION['adminlogin'])){
    		//dialihkan ke home bila sudah ada session user_login
    		header("location:login.php");
    	}
    ?>
    <html>
    <head>
    	<title>Absensi Vihara</title>
    	<meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

        <!-- Icon  -->
        <link rel="shortcut icon" href="../images/favicon.png">

    	<!-- Bootstrap Core CSS -->
        <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

        <!-- MetisMenu CSS -->
        <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

        <!-- Custom CSS -->
        <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

        <!-- Morris Charts CSS -->
        <link href="../vendor/morrisjs/morris.css" rel="stylesheet">

        <!-- Custom Fonts -->
        <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

        <!-- Lightbox css -->
        <link rel="stylesheet" href="../vendor/light-box/css/lightbox.css">

         <!-- Custom css -->
        <link rel="stylesheet" type="text/css" href="../dist/css/style.css">

    	<link rel="stylesheet" type="text/css" href="../dist/css/responsive.css">

    	<!-- jQuery -->
        <script src="../vendor/jquery/jquery.min.js"></script>

        <!-- Bootstrap Core JavaScript -->
        <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

        <!-- Metis Menu Plugin JavaScript -->
        <script src="../vendor/metisMenu/metisMenu.min.js"></script>

        <!-- Morris Charts JavaScript -->
        <script src="../vendor/raphael/raphael.min.js"></script>
        <script src="../vendor/morrisjs/morris.min.js"></script>
        <script src="../data/morris-data.js"></script>

        <!-- Custom Theme JavaScript -->
        <script src="../dist/js/sb-admin-2.js"></script>

    	<!-- ckeditor -->
    	<script type="text/javascript" src="../vendor/ckeditor/ckeditor.js"></script>

        <!-- Lightbox javascript -->
        <script src="../vendor/light-box/js/lightbox.js"></script>

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
    	
    	<script>
        $(document).ready(function(){
            CKEDITOR.config.height=285
            });
        // Create button back to top
        // When the user scrolls down 20px from the top of the document, show the button
        window.onscroll = function() {scrollFunction()};

        function scrollFunction() {
            if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
                document.getElementById("myBtn").style.display = "block";
            } else {
                document.getElementById("myBtn").style.display = "none";
            }
        }

        // When the user clicks on the button, scroll to the top of the document
        function topFunction() {
            document.body.scrollTop = 0;
            document.documentElement.scrollTop = 0;
        }
        </script>
        <style>
            #myBtn {
              display: none;
              position: fixed;
              bottom: 20px;
              right: 30px;
              z-index: 99;
              border: none;
              outline: none;
              color: black;
              cursor: pointer;
              padding: 15px;
              border-radius: 50%;
              text-align: center;
            }

            #myBtn:hover {
              opacity: 0.8;
              background-color: red;
              color:white;
              text-decoration: none;
            }
        </style>
    </head>
    <body>
    <a onclick="topFunction()" id="myBtn" title="Go to top"><i class="glyphicon glyphicon-chevron-up"></i> Top</a>
    <div id="wrapper">
    	<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="../index.php">Absensi Vihara</a>
            </div>
            <!-- /.navbar-header -->
            <ul class="nav navbar-top-links navbar-right">
                <li class="dropdown" style="float: right">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links --> 
            <div class="navbar-default navbar-fixed-side sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
    		            <li>
                            <a href="dashboard.php?page=users">Pengurus</a>
                        </li>
                        <li>
                            <a href="dashboard.php?page=umat">Umat</a>
                        </li>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>
        <div id="page-wrapper">
            <div class="col-md-12">
                <div class="row">
                <article>
                    <?php
                        if(isset($_GET['page'])){
                            $page = $_GET['page'];
                        }else{
                            $page = "dashboard";
                        }
                        switch($page){
                            case 'users':
                            include "users.php";
                            break;
                            
                            case 'users_search':
                            include "users_search.php";
                            break;
                            
                            case 'add_user':
                            include "add_user.php";
                            break;
                            
                            case 'add_user_query':
                            include "add_user_query.php";
                            break;
                            
                            case 'edit_user_query':
                            include "edit_user_query.php";
                            break;
                            
                            case 'edit_user':
                            include "edit_user.php";
                            break;
                            
                            case 'confirm_delete_users':
                            include "confirm_delete_users.php";
                            break;
                            
                            case 'delete_users_query':
                            include "delete_users_query.php";
                            break;

                            case 'umat':
                            include "umat.php";
                            break;

                            case 'add_umat':
                            include "add_umat.php";
                            break;

                            case 'add_umat_query':
                            include "add_umat_query.php";
                            break;
                                                    
                            default:
                            echo "<h1>Empty!!!</h1>";
                            break;
                        }
                    ?>
                </article>
                </div>
            </div>
        </div>
    </div>
    </body>
    </html>