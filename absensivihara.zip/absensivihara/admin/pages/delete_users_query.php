<?php
	//jika session user_login telah dimasukan
	if(!isset($_SESSION['adminlogin'])){
		//dialihkan ke home bila sudah ada session user_login
		header("location:login.php");
	}
?>
<?php
include "fn.php";
	if(isset($_GET['username'])){
			$username = $_GET['username'];
			
			$delete = "DELETE FROM users,member USING users JOIN member WHERE users.username ='$username' and member.user_id ='$username'";
			$query = mysqli_query($connection, $delete)or die($connection);
			if($query){
				echo '<div class="alert alert-success" role="alert"><strong>Success!</strong> Username '.$username.' is deleted</div>';
				echo '<a href="dashboard.php?page=users" class="btn btn-default">Back to users</a>';
			}
	}
?>