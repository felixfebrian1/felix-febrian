<?php
	//jika session user_login telah dimasukan
	if(!isset($_SESSION['adminlogin'])){
		//dialihkan ke home bila sudah ada session user_login
		header("location:login.php");
	}
?>
<?php
	$select = "SELECT * FROM users WHERE id='".$_GET['id']."'";
	$query = mysqli_query($connection,$select);
	if(mysqli_num_rows($query) > 0){
		$data=mysqli_fetch_object($query);
		$id = $data->id;
		$username = $data->username;
		$firstname = $data->firstname;
		$lastname = $data->lastname;
		$password = $data->password;
		$lastlogin = $data->last_login;
		$email = $data->email;
		$status = $data->status;
		$rule = $data->rule;
	}
?>
<div class="box">
	<div class="box-header">
		<h3 class="box-title"></h3>
	</div>
	<div class="box-body">
		<div class="row">
			<div class="col-md-8 col-sm-8 col-xs-8">
				<div class="panel panel-default">
							<div class="panel-heading">
								<?php
									$message = $_GET['message'];
									echo "<span style='color:red;'>".$message."</span>";
								?>
								<h3 class="panel-title">Edit user | admin</h3>
							</div>
							<div class="panel-body">
									<form action="dashboard.php?page=edit_user_query" method="post" name="register-form required">
										<input type="hidden" name="id" value="<?php echo $id ?>">
										<input type="hidden" name="username" value="<?php echo $username ?>">
										<input type="text" name="firstname" id="firstname" class="form-control" placeholder="First name" value="<?php echo $firstname?>" required><br/>
										<input type="text" name="lastname" id="lastname" class="form-control" placeholder="Last name" value="<?php echo $lastname?>" required><br/>
										<input type="email" name="email" id="email" class="form-control" placeholder="example@example.com" value="<?php echo $email?>" required><br/>
										<input type="text" name="username" id="username" class="form-control" placeholder="username" value="<?php echo $username?>" disabled><br/>
										<input type="password" name="password" id="password" class="form-control" placeholder="password" required><br/>
										<select name="status" class="form-control" required>
											<option value="active" <?php echo $status == 'active' ? 'selected' : '' ?>>Active</option>
											<option value="inactive" <?php echo $status == 'inactive' ? 'selected' : '' ?>>Inactive</option>
										</select><br/>
										<select name="rule" class="form-control" required>
											<option value="admin" <?php echo $rule == 'admin' ? 'selected' : '' ?>>Admin</option>
											<option value="user" <?php echo $rule == 'user' ? 'selected' : '' ?>>User</option>
										</select><br/>
										<input type="submit" name="update" value="Update" class="btn btn-default">
										<a href="dashboard.php?page=users" class="btn btn-default">Back</a>
									</form>
							</div>
				</div>
			</div>
		</div>
	</div>
</div>