<?php
	//jika session user_login telah dimasukan
	if(!isset($_SESSION['adminlogin'])){
		//dialihkan ke home bila sudah ada session user_login
		header("location:login.php");
	}
?>
<?php
	//include "fn.php";
	if(isset($_POST['update'])){
			$id = $_POST['id'];
			$lastname = $_POST['lastname'];
			$firstname = $_POST['firstname'];
			$email = $_POST['email'];
			$status = $_POST['status'];
			$rule = $_POST['rule'];
			$username = $_POST['username'];
			$pass = md5($_POST['password']);
			//$tag = $_POST['tag'];
			$date = date('Y-m-d H:i:s');
			//$author = $_SESSION['adminlogin'];
			//$photo = $_FILES['photo']['name'];
			
			
			$sql="select * from users where username = '$username'";
			$query = mysqli_query($connection,$sql)or die($connection);
			
				mysqli_query($connection,"UPDATE users SET firstname='$firstname', lastname='$lastname', email='$email', date_register='$date',status='$status',rule='$rule',username='$username',password='$pass' WHERE id = '$id'");
				/*
				echo "$firstname";
				echo "$lastname";
				echo "$email";
				echo "$username";
				echo "$password";
				echo "$status";
				echo "$rule";
				*/
				echo '<div class="alert alert-success" role="alert"><strong>Success!</strong> Successful updated</div>';
				echo '<a href="dashboard.php?page=edit_user&id='.$id.'" class="btn btn-default">Edit user</a> <a href="dashboard.php?page=users" class="btn btn-default">View users</a>';
	}
?>