<?php
	session_start();
	//jika session user_login telah dimasukan
	if(isset($_SESSION['adminlogin'])){
		//dialihkan ke home bila sudah ada session user_login
		header("location:dashboard.php?page=users");
	}else{
		//dialihkan ke login.php bila belum ada session user_login
		header("location:login.php");
	}
?>