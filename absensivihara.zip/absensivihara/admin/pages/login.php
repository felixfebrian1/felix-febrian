<?php
session_start();
	//jika session user_login telah dimasukan
	if(isset($_SESSION['adminlogin'])){
		//dialihkan ke home bila sudah ada session user_login
		header("location:dashboard.php");
	}
?>
<html>
<head>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
	<title>Absensi Vihara</title>
	<!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

	<!-- Icon  -->
	<link rel="shortcut icon" href="../images/favicon.png">

	<!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

    <style type="text/css">
    	/*Versi desktop*/
		body{
			background-image: url("../../asset/bg2.jpg");
			background-size: 100% 100%;
		}
		/*Versi handphone*/
		@media only screen and (max-width: 479px) {
			body{
				background-image: url("../../asset/bg2.jpg");
				background-size: 100%;
			}
		}	
		#login-box{
			margin: 100px auto !important;
			float:none;
		}
		.panel-default > .panel-heading  {
			background-color: transparent;
			border: none;
			color: black;
		}
		.panel-default{
			background-color: transparent;
		}
		.login{
			border: none;
		}
		.login a{
			text-decoration: none;
		}
		.checkbox label{
			color: white;
		}
		.group_btn{
			overflow: hidden;
		}
	</style>
</head>
<body>
<div class="container">
        <div class="row">
            <div class="col-md-4 col-md-offset-4" id="login-box">
            	<div class="logo">
            		<a href="dashboard.php"><img src="../../asset/logo.png" alt="" class="img-responsive"></a>
            	</div>
				<div class="panel panel-default login">
					<div class="panel-heading text-center">
						<div class="panel-title">
							<h1>Welcome Admin</h1>
							<?php
								$message = $_GET['message'];
								echo "<span style='color:red;'>".$message."</span>";
							?>
						</div>
					</div>
					<div class="panel-body">
						<?php
							session_start();
							include_once "connection.php";
							if(isset($_POST['submit'])){
								$username = $_POST['username'];
								$pass = md5($_POST['password']);
								
								$select = "SELECT * FROM admin WHERE username='$username' AND password='$pass' AND divisi= 'admin'";
								$query = mysqli_query($connection,$select);
								
							if(mysqli_fetch_row($query) > 0){
									$_SESSION['adminlogin'] = $username;
									$_SESSION['statuslogin'] = 1;
									
									header('location: index.php');
								}else{
									echo " <div class='alert alert-danger'>Username or password is incorrect </div>";
								}
							}
						?>
						<form action="<?= $_SERVER['PHP_SELF'] ?>" method="post" name="login-form">
							<fieldset>
                                <div class="form-group">
									<input type="text" name="username" id="username" class="form-control" placeholder="username">
								</div>
								<div class="form-group">
									<input type="password" name="password" id="password" class="form-control" placeholder="password">
								</div>
								<input type="submit" name="submit" value="LOGIN ADMIN" class="btn btn-lg btn-success btn-block"><br>
							</fieldset>
						</form>
					</div>
				</div>
			</div>
		<div>
	</div>
</body>
</html>