<?php
	//jika session user_login telah dimasukan
	if(!isset($_SESSION['adminlogin'])){
		//dialihkan ke home bila sudah ada session user_login
		header("location:login.php");
	}
?>
<style>
* {
  box-sizing: border-box;
}

#search{
	float: right;
}

#myInput {
  background-image: url('../images/searchicon.png');
  background-position: 5px 5px;
  background-repeat: no-repeat;
  width: 100%;
  font-size: 16px;
  padding: 10px 10px 10px 10px;
  border: 1px solid #ddd;
  margin-bottom: 12px;
}

#myTable {
  border-collapse: collapse;
  width: 100%;
  border: 1px solid #ddd;
  font-size: 18px;
}

#myTable th, #myTable td {
  text-align: left;
  padding: 12px;
}

#myTable tr {
  border-bottom: 1px solid #ddd;
}

#myTable tr.header, #myTable tr:hover {
  background-color: #f1f1f1;
}
</style>
<div class="box">
	<div class="box-header">
		<h3 class="box-title">Pengurus</h3>
	</div>
	<div class="box-body">
		<div class="nav-table">
			<div class="row">
				<div class="col-md-8 col-sm-8 col-xs-3">
					
				</div>
				<div class="col-md-4 col-sm-4 col-xs-9">
					<form action="dashboard.php?page=users_search" method="get" class="search">
						<div class="input-group">
							<input type="hidden" name="page" value="users_search">
							<input type="text" name="search" placeholder="search for..." class="form-control">
							<span class="input-group-btn">
								<input type="submit" name="search_btn" class="btn btn-default" value="Search">
							</span>
						</div>
					</form>
				</div>
			</div>
		</div>
	
		<div class="table-responsive">
			<table id="myTable" class="table">
				<thead>
				 <tr class="header">
					<th>No</th>
					<th>ID</th>
					<th>Name</th>
					<th>No Telp</th>
					<th>Username</th>
					<th>Divisi</th>
					<th>Status</th>
					<th>Action</th>
				 </tr>
				</thead>
				<tbody>
					<?php 
						$dataPerPage = 20;
							if(isset($_GET['p'])){
								$p = $_GET['p'];
							}else{
								$p = 1;
							}
							$start = ($p - 1) * $dataPerPage;
							$no = 1;
						$select = "SELECT * FROM admin ORDER BY adminid DESC LIMIT $start,$dataPerPage";
						$query = mysqli_query($connection,$select);
						if(mysqli_num_rows($query) > 0){
							while($data=mysqli_fetch_object($query)){
								$id = $data->adminid;
								$username = $data->username;
								$name = $data->nama;
								$notelp = $data->notelp;
								$divisi = $data->divisi;
								// $status = $data->status;
								
								echo "<tr>";
								echo "<td>".$no++."</td>";
								echo "<td>".$id."</td>";
								echo "<td>".$name."</td>";
								echo "<td>".$notelp."</td>";
								echo "<td>".$username."</td>";
								echo "<td>".$divisi."</td>";
								echo "<td>test</td>";
								// echo "<td>".$status."</td>";
								//echo "<td><div style='width:140px'><a href='uploader/".$data->photo."' target='blank' ><img src='uploader/".$photo."' class='img-responsive'></a></div></td>";
								echo "<td><a href='dashboard.php?page=edit_user&id=$id' class='btn btn-primary'>Edit<a> 
										<a href='dashboard.php?page=confirm_delete_users&username=$username' class='btn btn-danger'>Delete</a>
									</td>";
								echo "</tr>";
							}
						}else{
							echo "<tr>";
							echo "<td colspan='6'>User is not signed yet</td>";
							echo "</tr>";
						}
					?>
				</tbody>
			</table>
		</div>
		<ul class="pagination pull-right">
			<?php
				error_reporting('E_NOTICE');

					$select_page = mysqli_query($connection,"SELECT COUNT(*) AS jum_data FROM admin");
					$data_page = mysqli_fetch_object($select_page);

					$jumData = $data_page->jum_data;//4
					//membulatkan jumlah halaman
					$jumPage = ceil($jumData/$dataPerPage);
					//membuat tombol kembali
					
					if($p > 1) echo "<li><a href='dashboard.php?page=users&p=".($p-1)."' aria-label='Previous'><span aria-hidden='true'>&laquo;</span></a></li>";
					
					for($i = 1; $i <= $jumPage; $i++){
						if((($i >= $p - 3) && ($i <= $p + 3)) || $i == 1 || $i == $jumPage){
							//penggulung halaman setelah
							if($showPage == 1 && $i != 2) echo "<li class='disabled'><a href='#'><span>...</span></a></li>";
							//penggulung halaman sebelum
							if($showPage != ($jumPage -1) && $i == $jumPage) echo "<li class='disabled'><a href='#'><span>...</span></a></li>";
							//halaman yang aktif
							if($i == $p) echo "<li class='active'><a href='#'>$p<span class='sr-only'>(current)</span></a></li>";
							//halaman yang lain
							else echo "<li><a href='dashboard.php?page=users&p=$i'>$i</a></li>";
							$showPage = $i;
						}
					}
					
					if($p < $jumPage) echo "<li><a href='dashboard.php?page=users&p=".($p+1)."' aria-label='Next'><span aria-hidden='true'>&raquo;</span></a></li>"
			?>
		</ul>		
	</div>
</div>
<br style="clear:both">