<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="home.css">
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	<link rel="shortcut icon" href="../images/favicon.png">
    <script src="../vendor/jquery/jquery.min.js"></script>
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>

<div class="navbar">
	<ul>
		  <li><a href="../admin/pages/login.php"><img class="logo" src="../asset/logo.png"></a></li>
  		  <li><h1 style="text-align: center;">Tanggal:<?php echo(strftime("%A,%d-%B-%Y"));?>
  		  	  </h1>
  		  </li>
	</ul>
</div>

<div>
	<form action="/action_page.php" style="max-width:500px;margin:auto">
  <h2 style="text-align: center;">PLEASE INPUT YOUR ID</h2>
  <div class="input-container">
    <i class="fa fa-user icon"></i>
    <input class="input-field" type="text" placeholder="USERCODE" name="USERCODE">
  </div>

  <button type="submit" class="btn">SUBMIT</button>
</form>
</div>


</body>
</html>