<?php 

header("location:home/home.php");	

?>